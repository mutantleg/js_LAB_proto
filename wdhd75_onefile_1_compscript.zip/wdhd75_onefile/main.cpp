
#pragma warning (disable : 4786)
#pragma warning (disable : 4996)
#pragma warning (disable : 4267)

#include <stdio.h>
#include <algorithm>
#include <string>

std::string canvas;
std::string xcanvas;
std::string repfile;

void fileToStr(std::string fname, std::string & out)
{
 int size;
 char * buff;

 out.clear();

 FILE * f;
  f = fopen(fname.c_str(), "rb");
  if (f==0)
  {
    printf("couldnt load [%s] \n", fname.c_str() ); return; }
    fseek(f, 0, SEEK_END);
    size = ftell(f);
    fseek(f, 0, SEEK_SET);
     buff = new  char[size+1];
     fread(buff, size, 1, f);  
  fclose(f);

  buff[size] = 0;

  out = buff;
  std::replace( out.begin(), out.end(), '\r', ' ');

  /*
  f = fopen("test.txt", "wb");
  fwrite(buff, size, 1, f);
  fclose(f);
*/

  delete [] buff;
}//filetostr

int main(int argc, char**argv)
{

 std::string fname;
 fname = "canvas.html";

 fileToStr(fname, canvas);

  

 /*
  FILE * f;
  f = fopen("out.js", "wt");
  fwrite(canvas.c_str(), canvas.size(), 1, f);
  fclose(f);
  */


  int v0, v1;
  int k0, k1;
  int i;
  v1 = 0;

  for (i=0;i<1024;i+=1)
  {
    v1+=1;
    v0 = canvas.find("<script src=\"", v1);
    if (v0==-1) { break; }
    printf("%d \n", v0);
    v1 = canvas.find("</script>",v0);
    printf("%d \n", v1);

    std::string rep;
    rep = canvas.substr(v0,v1-v0+9);
    printf("rep %s \n", rep.c_str() );


    k0 = rep.find("\"");
    k1 = rep.find("\"", k0+1);
    std::string rname;
    rname = rep.substr(k0+1,k1-k0-1);
    printf("rname %d %d %s \n", k0, k1, rname.c_str() );

    fileToStr(rname, repfile);

    if (repfile.size() > 0)
    {
      xcanvas = canvas.substr(0,v0);
      xcanvas += "<script>\n";
      xcanvas += repfile;
      xcanvas += "</script>\n";
      xcanvas += canvas.substr(v1+9, -1);
      canvas = xcanvas;
      //canvas = repfile;
      //canvas = canvas.substr(v1+9, -1);
    }
  }//nexti

  FILE * f;
  f = fopen("out.html", "wt");
  fwrite(canvas.c_str(), canvas.size(), 1, f);
  fclose(f);

  
 return 0;
}//main
