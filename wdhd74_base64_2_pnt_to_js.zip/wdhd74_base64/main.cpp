
#pragma warning (disable : 4786)
#pragma warning (disable : 4996)

#include <stdio.h>
#include <string>


typedef unsigned long ulong;


int main(int argc, char**argv)
{
  if (argc < 3) 
  { printf("need parameter: filename varname \n"); return 0; }

 long size;
 unsigned char * buff;
 std::string fname;
 std::string varname;
// fname = "tile000.png";
 fname = argv[1];
 varname = argv[2];

 FILE * f;
  f = fopen(fname.c_str(), "rb");
  if (f==0)
  { printf("couldnt load [%s] \n", fname.c_str() ); return 0; }
    fseek(f, 0, SEEK_END);
    size = ftell(f);
    fseek(f, 0, SEEK_SET);
     buff = new unsigned char[size];
     fread(buff, size, 1, f);  
  fclose(f);
  
  /*
 f = fopen("out.dat", "wb");
 fwrite(buff,size,1,f);
 fclose(f);
  */


 unsigned char * out;
 out = new unsigned char[size*2];


  const char *alpha =	"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				"abcdefghijklmnopqrstuvwxyz"
				"0123456789+/";
	unsigned char c[4];
	unsigned long u;
  int k; int i;

  k = 0;



  int num;
  num = (size / 3) * 3;
  printf("num %d size  %d \n",num,size);

  for (i=0;i<num;i+=3)
  { 
   // printf("%d ", i);
	//	c[1] = c[2] = 0;

    c[0] = buff[i];
    c[1] = buff[i+1];
    c[2] = buff[i+2];

		u = (ulong)c[0]<<16 | (ulong)c[1]<<8 | (ulong)c[2];

    out[k] = alpha[u>>18];
    out[k+1] = alpha[u>>12 & 63];
    out[k+2] = alpha[u>>6 & 63];
    out[k+3] = alpha[u & 63];

    k += 4;
   
  }//nexti
 //printf("last %d \n", i);
  num = size - num;

  c[1] = 0; c[2]=0;
  c[0] = buff[i];
  if (num>1) { c[1] = buff[i+1]; }
  if (num>2) { c[2] = buff[i+2]; }

  u = (ulong)c[0]<<16 | (ulong)c[1]<<8 | (ulong)c[2];

   out[k] = alpha[u>>18];
   out[k+1] = alpha[u>>12 & 63];

   if (num < 2) { out[k+2] = '='; }
   else { out[k+2] = alpha[u>>6 & 63]; }
   if (num < 3) { out[k+3] = '='; }
   else { alpha[u & 63]; }
  k += 4;

  printf("i %d  size %d  left %d \n", i ,size, num);

  out[k] = 0;
  k+=1;

  std::string outName;
  outName = "i_"+ fname + ".js";
  printf("outname [%s] \n",outName.c_str() );

  f = fopen(outName.c_str(), "wt");
  fprintf(f, "var %s = \"", argv[2]);
  fprintf(f,"data:image/png;base64,");
  fprintf(f, "%s", out);
  fprintf(f, "\";", out);
 fclose(f);

	 // putchar(len < 2 ? '=' : alpha[u>>6 & 63]);
	//	putchar(len < 3 ? '=' : alpha[u & 63]);
  
  
  
  delete [] buff;
  delete [] out;

 return 0;
}//main
